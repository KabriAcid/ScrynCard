---
name: scryn-design
description: Design and build conventions for the Scryn V3 reward card platform. Use whenever working on the Scryn project — including landing pages, card order flows, redemption flows, UI components, styling decisions, or any guest-facing feature. This skill ensures premium Apple/Stripe/Linear aesthetic, proper redemption business rules, and consistent architecture.
---

# Scryn V3 Design System & Architecture

This skill governs all design, UI, and frontend architecture decisions for the Scryn digital reward card platform.

## Platform Overview

Scryn is a premium SaaS platform that enables businesses to order customized physical reward cards and allows customers to redeem them for digital rewards (airtime, data). The platform must feel corporate, trustworthy, and high-end — never startup-clutter.

## Design Philosophy

### Aesthetic Direction
- **Premium, elegant, corporate, trustworthy, high-end**
- Inspired by: Apple, Stripe, Linear, Notion, Vercel
- Avoid startup-style clutter, excessive animations, or playful colors
- Focus on: whitespace, typography, hierarchy, premium presentation

### Key Principles
- Generous whitespace — let content breathe
- Large, confident typography with tight letter-spacing on headlines
- Neutral color palette with strategic accent usage
- Subtle animations only (300-600ms, ease-out)
- Glassmorphism used sparingly for elevated surfaces
- Every element must justify its existence

## Color System

```css
:root {
  /* Backgrounds */
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f7;
  --bg-tertiary: #fafafa;
  --bg-dark: #1d1d1f;

  /* Text */
  --text-primary: #1d1d1f;
  --text-secondary: #86868b;
  --text-tertiary: #a1a1a6;
  --text-inverse: #f5f5f7;

  /* Accents — use sparingly */
  --accent-blue: #0071e3;
  --accent-green: #30d158;
  --accent-orange: #ff9f0a;
  --accent-red: #ff3b30;

  /* Surfaces */
  --surface-elevated: rgba(255, 255, 255, 0.8);
  --border-subtle: rgba(0, 0, 0, 0.08);
  --border-medium: rgba(0, 0, 0, 0.12);
}

@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: #000000;
    --bg-secondary: #1d1d1f;
    --bg-tertiary: #161617;
    --bg-dark: #f5f5f7;
    --text-primary: #f5f5f7;
    --text-secondary: #a1a1a6;
    --text-tertiary: #86868b;
    --text-inverse: #1d1d1f;
    --surface-elevated: rgba(29, 29, 31, 0.8);
    --border-subtle: rgba(255, 255, 255, 0.08);
    --border-medium: rgba(255, 255, 255, 0.12);
  }
}
```

## Typography

```css
font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Segoe UI', sans-serif;

/* Headlines — tight, confident */
h1 { font-size: clamp(2.5rem, 5vw + 1rem, 4.5rem); font-weight: 700; letter-spacing: -0.03em; line-height: 1.05; }
h2 { font-size: clamp(2rem, 4vw + 0.5rem, 3.5rem); font-weight: 600; letter-spacing: -0.02em; line-height: 1.1; }
h3 { font-size: clamp(1.5rem, 2vw + 0.5rem, 2rem); font-weight: 600; letter-spacing: -0.01em; line-height: 1.2; }

/* Body — readable */
p, li { font-size: 1.0625rem; line-height: 1.6; color: var(--text-secondary); }

/* Labels — small, uppercase for sections */
.label { font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text-tertiary); }
```

## Spacing System

8px-based scale. Use these CSS custom properties:

```css
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-24: 6rem;     /* 96px */
--space-32: 8rem;     /* 128px */
```

Section padding: `padding: var(--space-24) var(--space-8)` on desktop, `var(--space-16) var(--space-4)` on mobile.

## Component Patterns

### Buttons

```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-6);
  border-radius: 980px; /* Apple's pill shape */
  font-weight: 500;
  font-size: 1rem;
  transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
  min-height: 44px;
}

.btn-primary {
  background: var(--accent-blue);
  color: white;
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 113, 227, 0.3);
}

.btn-secondary {
  background: transparent;
  color: var(--text-primary);
  border: 1.5px solid var(--border-medium);
}
.btn-secondary:hover {
  background: var(--bg-secondary);
}

.btn-ghost {
  background: transparent;
  color: var(--accent-blue);
}
```

### Cards

```css
.card {
  background: var(--bg-primary);
  border: 1px solid var(--border-subtle);
  border-radius: 20px;
  padding: var(--space-8);
  transition: all 400ms cubic-bezier(0.4, 0, 0.2, 1);
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 48px rgba(0, 0, 0, 0.08);
}

.card-glass {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(20px) saturate(180%);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
```

### Forms / Inputs

```css
.input {
  width: 100%;
  padding: var(--space-4) var(--space-6);
  border: 1.5px solid var(--border-subtle);
  border-radius: 12px;
  font-size: 1rem;
  background: var(--bg-primary);
  color: var(--text-primary);
  transition: all 200ms ease;
}

.input:focus {
  outline: none;
  border-color: var(--accent-blue);
  box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.15);
}

.input::placeholder {
  color: var(--text-tertiary);
}
```

### Navigation

- Fixed top navbar
- Background: `var(--surface-elevated)` with `backdrop-filter: blur(20px)`
- Border-bottom: `1px solid var(--border-subtle)`
- Height: 64px
- Logo left, nav links center, CTAs right
- On mobile: hamburger menu with full-screen overlay

## Animation Guidelines

- **Duration**: 300ms for micro-interactions, 500ms for reveals, 600ms for page transitions
- **Easing**: `cubic-bezier(0.4, 0, 0.2, 1)` for most, `cubic-bezier(0, 0, 0.2, 1)` for exits
- **Properties**: Only animate `transform` and `opacity` for performance
- **Entrance**: Fade in + translate Y (20-30px) with staggered delays (100ms between items)
- **Hover**: Subtle lift (`translateY(-4px)`) + shadow increase
- **Respect**: `prefers-reduced-motion` — disable animations for users who prefer reduced motion

## Page-Specific Rules

### Landing Page
- Hero: Full viewport height, centered content, massive headline
- Trusted By: Logo row, grayscale, opacity 0.5
- How It Works: 5 steps, horizontal on desktop, vertical on mobile
- Industry Use Cases: Card grid with hover reveals
- Card Showcase: Large carousel with premium mockups
- FAQ: Accordion, clean borders

### Card Order Page (/order)
- NOT a checkout — only order submission
- Multi-step or single long form
- Fields: Business Name, Email, Phone, Industry, Card Purpose, Quantity, Value, Notes, Logo Upload, Branding Upload
- Confirmation screen: "Request Submitted" — no payment processing

### Redemption Flow (/redeem/*)
This is the MOST critical flow. Follow these routes exactly:

1. `/redeem` — Enter Serial Number + Gift Code
2. `/redeem/verify` — Enter Phone Number + Select Network (MTN, Airtel, Glo, 9mobile)
3. `/redeem/options` — Display reward options based on Card Value + Network
4. `/redeem/confirm` — Review selection, confirm
5. `/redeem/success` — Success animation, reference ID
6. `/redeem/error` — Error state with retry

**Critical Business Rule — Reward Options:**

| Card Value | Network | Option A | Option B |
|------------|---------|----------|----------|
| ₦500 | MTN | 1GB Data | ₦400 Airtime |
| ₦500 | Airtel | 500MB Data | ₦400 Airtime |
| ₦500 | Glo | 1GB Data | ₦400 Airtime |
| ₦500 | 9mobile | 1GB Data | ₦400 Airtime |

User chooses ONE option. Display clearly with radio-style selection.

### Card Gallery (/gallery)
- Categories: Hotels, Restaurants, Retail, Politics, Corporate, Influencers, Events, Education, Religious
- Large card mockups, hover reveals details
- Filter by category

## Tech Stack (MUST USE)

- Next.js 15 App Router
- TypeScript
- Tailwind CSS
- Shadcn UI
- React Hook Form
- Zod
- Framer Motion
- Lucide Icons
- Supabase (database, auth when needed)

## Code Quality Standards

- Production-ready structure
- Mobile-first responsive design
- Accessibility: WCAG AA minimum, focus states, ARIA labels, keyboard navigation
- Reusable components with clear interfaces
- Server Actions where appropriate
- Proper loading, error, and empty states
- SEO: metadata, Open Graph, structured data
- NEVER use purple, indigo, or violet hues unless explicitly requested

## What to Avoid

- Startup-style clutter, excessive gradients, playful illustrations
- Animating width/height/top/left — only transform and opacity
- Complex multi-step animations that feel gimmicky
- Sacrificing accessibility for aesthetics
- Using purple/indigo as default "beautiful" colors
- Building admin dashboards, business dashboards, or super admin panels for this phase

## Current Phase Scope

**ONLY build guest-facing pages:**
- Landing Page
- Card Order Page
- Card Gallery
- Redemption Flow (all steps)
- About Page
- Contact Page
- Privacy Policy
- Terms of Service

**DO NOT build:**
- Admin Dashboard
- Super Admin Dashboard
- Business Dashboard
- Authentication (unless explicitly requested later)
