'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, Check, User, Building2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <div className="section-padding py-12 lg:py-20">
          <div className="max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Contact</p>
              <h1 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Get in Touch</h1>
              <p className="text-scryn-muted max-w-xl mx-auto">
                Have questions about Scryn? We are here to help. Reach out and our team will respond within 24 hours.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="lg:col-span-2 space-y-8"
              >
                <div>
                  <h3 className="text-lg font-bold text-scryn-text mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <a
                      href="mailto:hello@scryn.com"
                      className="flex items-center gap-3 text-scryn-muted hover:text-scryn-primary transition-colors"
                    >
                      <div className="w-10 h-10 rounded-xl bg-scryn-primary/10 flex items-center justify-center">
                        <Mail className="w-5 h-5 text-scryn-primary" />
                      </div>
                      <span>hello@scryn.com</span>
                    </a>
                    <a
                      href="tel:+2348001234567"
                      className="flex items-center gap-3 text-scryn-muted hover:text-scryn-primary transition-colors"
                    >
                      <div className="w-10 h-10 rounded-xl bg-scryn-primary/10 flex items-center justify-center">
                        <Phone className="w-5 h-5 text-scryn-primary" />
                      </div>
                      <span>+234 800 123 4567</span>
                    </a>
                    <div className="flex items-center gap-3 text-scryn-muted">
                      <div className="w-10 h-10 rounded-xl bg-scryn-primary/10 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-scryn-primary" />
                      </div>
                      <span>Lagos, Nigeria</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-scryn-text mb-4">Business Hours</h3>
                  <div className="space-y-2 text-sm text-scryn-muted">
                    <p>Monday – Friday: 9:00 AM – 6:00 PM WAT</p>
                    <p>Saturday: 10:00 AM – 4:00 PM WAT</p>
                    <p>Sunday: Closed</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="lg:col-span-3"
              >
                {submitted ? (
                  <div className="bg-white rounded-2xl border border-scryn-border p-8 text-center">
                    <div className="w-16 h-16 rounded-full bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
                      <Check className="w-8 h-8 text-scryn-primary" />
                    </div>
                    <h2 className="text-xl font-bold text-scryn-text mb-2">Message Sent</h2>
                    <p className="text-scryn-muted mb-6">
                      Thank you for reaching out. We will get back to you within 24 hours.
                    </p>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="text-sm text-scryn-primary hover:underline"
                    >
                      Send another message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8 space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-scryn-text mb-2">Name</label>
                        <div className="relative">
                          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                          <input
                            type="text"
                            required
                            placeholder="Your name"
                            className="input pl-12"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-scryn-text mb-2">Email</label>
                        <div className="relative">
                          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                          <input
                            type="email"
                            required
                            placeholder="you@email.com"
                            className="input pl-12"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-scryn-text mb-2">Phone</label>
                        <div className="relative">
                          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                          <input
                            type="tel"
                            placeholder="+234 800 000 0000"
                            className="input pl-12"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-scryn-text mb-2">Company</label>
                        <div className="relative">
                          <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                          <input
                            type="text"
                            placeholder="Your company"
                            className="input pl-12"
                            value={formData.company}
                            onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Message</label>
                      <textarea
                        required
                        rows={4}
                        placeholder="How can we help you?"
                        className="input resize-none"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      />
                    </div>

                    <button type="submit" className="btn-primary w-full group">
                      Send Message
                      <Send className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </form>
                )}
              </motion.div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
