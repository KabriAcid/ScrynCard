'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ChevronRight, Upload, Building2, Mail, Phone, Hash, FileText, Image } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const industries = ['Hotels', 'Restaurants', 'Retail', 'Politics', 'Corporate', 'Influencers', 'Events', 'Education', 'Religious'];
const quantities = ['100', '250', '500', '1000', '2500', '5000'];
const values = ['₦500', '₦1,000', '₦2,000', '₦5,000', '₦10,000'];

export default function OrderPage() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    businessName: '',
    email: '',
    phone: '',
    industry: '',
    purpose: '',
    quantity: '',
    value: '',
    notes: '',
  });

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const canProceed = () => {
    if (step === 1) return formData.industry && formData.quantity && formData.value;
    if (step === 2) return formData.businessName && formData.email && formData.phone;
    return true;
  };

  if (submitted) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center max-w-md mx-auto px-6 py-20"
          >
            <div className="w-20 h-20 rounded-full bg-scryn-primary/10 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-scryn-primary" />
            </div>
            <h1 className="text-3xl font-bold text-scryn-text mb-4">Request Submitted</h1>
            <p className="text-scryn-muted mb-8">
              Thank you for your interest! Our team will review your request and contact you within 24 hours to finalize your order.
            </p>
            <a href="/" className="btn-primary">Return Home</a>
          </motion.div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <div className="section-padding py-12 lg:py-20">
          <div className="max-w-2xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Order Cards</p>
              <h1 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Request Custom Cards</h1>
              <p className="text-scryn-muted">Tell us what you need and we will get back to you.</p>
            </motion.div>

            <div className="flex items-center justify-center gap-2 mb-10">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                      s <= step ? 'bg-scryn-primary text-white' : 'bg-scryn-border text-scryn-muted'
                    }`}
                  >
                    {s < step ? <Check className="w-5 h-5" /> : s}
                  </div>
                  {s < 3 && <div className={`w-12 h-0.5 ${s < step ? 'bg-scryn-primary' : 'bg-scryn-border'}`} />}
                </div>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
                >
                  <h2 className="text-xl font-bold text-scryn-text mb-6">Card Details</h2>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Industry</label>
                      <div className="grid grid-cols-3 gap-2">
                        {industries.map((ind) => (
                          <button
                            key={ind}
                            onClick={() => updateField('industry', ind)}
                            className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all ${
                              formData.industry === ind
                                ? 'bg-scryn-primary text-white'
                                : 'bg-scryn-bg text-scryn-muted hover:bg-scryn-primary/10'
                            }`}
                          >
                            {ind}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Card Purpose</label>
                      <input
                        type="text"
                        placeholder="e.g., Customer Loyalty Program"
                        className="input"
                        value={formData.purpose}
                        onChange={(e) => updateField('purpose', e.target.value)}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Quantity</label>
                      <div className="grid grid-cols-3 gap-2">
                        {quantities.map((q) => (
                          <button
                            key={q}
                            onClick={() => updateField('quantity', q)}
                            className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all ${
                              formData.quantity === q
                                ? 'bg-scryn-primary text-white'
                                : 'bg-scryn-bg text-scryn-muted hover:bg-scryn-primary/10'
                            }`}
                          >
                            {q}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Card Value</label>
                      <div className="grid grid-cols-3 gap-2">
                        {values.map((v) => (
                          <button
                            key={v}
                            onClick={() => updateField('value', v)}
                            className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all ${
                              formData.value === v
                                ? 'bg-scryn-primary text-white'
                                : 'bg-scryn-bg text-scryn-muted hover:bg-scryn-primary/10'
                            }`}
                          >
                            {v}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
                >
                  <h2 className="text-xl font-bold text-scryn-text mb-6">Business Information</h2>

                  <div className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Business Name</label>
                      <div className="relative">
                        <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                        <input
                          type="text"
                          placeholder="Your business name"
                          className="input pl-12"
                          value={formData.businessName}
                          onChange={(e) => updateField('businessName', e.target.value)}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                        <input
                          type="email"
                          placeholder="you@business.com"
                          className="input pl-12"
                          value={formData.email}
                          onChange={(e) => updateField('email', e.target.value)}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Phone Number</label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                        <input
                          type="tel"
                          placeholder="+234 800 000 0000"
                          className="input pl-12"
                          value={formData.phone}
                          onChange={(e) => updateField('phone', e.target.value)}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-scryn-text mb-2">Additional Notes</label>
                      <div className="relative">
                        <FileText className="absolute left-4 top-4 w-5 h-5 text-scryn-muted" />
                        <textarea
                          placeholder="Any special requirements..."
                          rows={3}
                          className="input pl-12 resize-none"
                          value={formData.notes}
                          onChange={(e) => updateField('notes', e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
                >
                  <h2 className="text-xl font-bold text-scryn-text mb-6">Review & Submit</h2>

                  <div className="space-y-4 mb-8">
                    {[
                      { label: 'Business Name', value: formData.businessName, icon: Building2 },
                      { label: 'Email', value: formData.email, icon: Mail },
                      { label: 'Phone', value: formData.phone, icon: Phone },
                      { label: 'Industry', value: formData.industry, icon: Hash },
                      { label: 'Quantity', value: formData.quantity, icon: Hash },
                      { label: 'Card Value', value: formData.value, icon: Hash },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center justify-between py-3 border-b border-scryn-border last:border-0">
                        <div className="flex items-center gap-3">
                          <item.icon className="w-4 h-4 text-scryn-muted" />
                          <span className="text-sm text-scryn-muted">{item.label}</span>
                        </div>
                        <span className="text-sm font-medium text-scryn-text">{item.value || '-'}</span>
                      </div>
                    ))}
                  </div>

                  <div className="border-2 border-dashed border-scryn-border rounded-xl p-8 text-center mb-6">
                    <Upload className="w-8 h-8 text-scryn-muted mx-auto mb-3" />
                    <p className="text-sm text-scryn-muted mb-1">Upload logo & branding assets</p>
                    <p className="text-xs text-scryn-muted">(Optional — you can also email these later)</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center justify-between mt-8">
              {step > 1 ? (
                <button
                  onClick={() => setStep(step - 1)}
                  className="text-sm font-medium text-scryn-muted hover:text-scryn-text transition-colors"
                >
                  Back
                </button>
              ) : (
                <div />
              )}

              {step < 3 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  disabled={!canProceed()}
                  className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                  <ChevronRight className="w-4 h-4 ml-2" />
                </button>
              ) : (
                <button
                  onClick={() => setSubmitted(true)}
                  className="btn-primary"
                >
                  Submit Request
                  <Check className="w-4 h-4 ml-2" />
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
