'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Hotel, UtensilsCrossed, ShoppingBag, Vote, Building2, Megaphone, PartyPopper, GraduationCap, Church, Gift } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const categories = [
  { id: 'all', label: 'All Cards' },
  { id: 'hotels', label: 'Hotels', icon: Hotel },
  { id: 'restaurants', label: 'Restaurants', icon: UtensilsCrossed },
  { id: 'retail', label: 'Retail', icon: ShoppingBag },
  { id: 'politics', label: 'Politics', icon: Vote },
  { id: 'corporate', label: 'Corporate', icon: Building2 },
  { id: 'influencers', label: 'Influencers', icon: Megaphone },
  { id: 'events', label: 'Events', icon: PartyPopper },
  { id: 'education', label: 'Education', icon: GraduationCap },
  { id: 'religious', label: 'Religious', icon: Church },
];

const cards = [
  { id: 1, name: 'Hilton Rewards', category: 'hotels', value: '₦5,000', gradient: 'from-amber-500 to-orange-600' },
  { id: 2, name: 'Sheraton Club', category: 'hotels', value: '₦10,000', gradient: 'from-blue-600 to-indigo-700' },
  { id: 3, name: 'Dominos Perks', category: 'restaurants', value: '₦2,500', gradient: 'from-rose-500 to-pink-600' },
  { id: 4, name: 'Cold Stone Treats', category: 'restaurants', value: '₦1,000', gradient: 'from-pink-400 to-rose-500' },
  { id: 5, name: 'Shoprite Rewards', category: 'retail', value: '₦5,000', gradient: 'from-red-600 to-red-700' },
  { id: 6, name: 'Campaign Supporter', category: 'politics', value: '₦2,000', gradient: 'from-green-600 to-emerald-700' },
  { id: 7, name: 'Employee Appreciation', category: 'corporate', value: '₦10,000', gradient: 'from-slate-600 to-slate-700' },
  { id: 8, name: 'Creator Perks', category: 'influencers', value: '₦1,000', gradient: 'from-violet-500 to-purple-600' },
  { id: 9, name: 'VIP Access', category: 'events', value: '₦3,000', gradient: 'from-fuchsia-500 to-pink-600' },
  { id: 10, name: 'Student Rewards', category: 'education', value: '₦500', gradient: 'from-cyan-500 to-blue-600' },
  { id: 11, name: 'Congregation Gift', category: 'religious', value: '₦2,000', gradient: 'from-yellow-500 to-amber-600' },
  { id: 12, name: 'Genesis Deluxe', category: 'restaurants', value: '₦5,000', gradient: 'from-emerald-500 to-teal-600' },
];

export default function GalleryPage() {
  const [activeCategory, setActiveCategory] = useState('all');

  const filtered = activeCategory === 'all' ? cards : cards.filter((c) => c.category === activeCategory);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <div className="section-padding py-12 lg:py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Card Gallery</p>
            <h1 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Explore Card Designs</h1>
            <p className="text-scryn-muted">Browse our collection of premium reward card designs across industries.</p>
          </motion.div>

          <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeCategory === cat.id
                    ? 'bg-scryn-primary text-white'
                    : 'bg-scryn-bg text-scryn-muted hover:bg-scryn-primary/10 hover:text-scryn-primary'
                }`}
              >
                {cat.icon && <cat.icon className="w-3.5 h-3.5" />}
                {cat.label}
              </button>
            ))}
          </div>

          <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((card, i) => (
              <motion.div
                key={card.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="group"
              >
                <div className={`relative aspect-[1.586/1] rounded-2xl bg-gradient-to-br ${card.gradient} shadow-lg overflow-hidden transition-all duration-300 group-hover:shadow-xl group-hover:shadow-scryn-primary/10 group-hover:-translate-y-1`}>
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(255,255,255,0.1)_0%,transparent_50%)]" />

                  <div className="relative h-full flex flex-col justify-between p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center">
                          <Gift className="w-3.5 h-3.5 text-white" />
                        </div>
                        <span className="text-white/90 text-xs font-medium">Scryn</span>
                      </div>
                      <span className="text-white/60 text-xs font-mono">{card.value}</span>
                    </div>

                    <div>
                      <div className="text-white/50 text-[10px] mb-0.5">Gift Card</div>
                      <div className="text-white text-base font-bold">{card.name}</div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-white/30 text-[9px] font-mono tracking-widest">XXXX-XXXX-XXXX</div>
                      <div className="w-8 h-6 rounded bg-white/20" />
                    </div>
                  </div>

                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">View Details</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
