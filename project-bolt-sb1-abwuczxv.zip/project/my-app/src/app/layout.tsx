import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Scryn - Physical Cards. Digital Rewards.",
  description: "Transform customer appreciation into measurable engagement with Scryn's digital reward card platform.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
