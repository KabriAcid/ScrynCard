'use client';

import { motion } from 'framer-motion';
import { CheckCircle, RotateCcw, Home, Copy } from 'lucide-react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function SuccessPage() {
  const referenceId = 'SCR-' + Math.random().toString(36).substr(2, 9).toUpperCase();

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 20 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
              className="w-24 h-24 rounded-full bg-scryn-primary/10 flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle className="w-12 h-12 text-scryn-primary" />
            </motion.div>

            <h1 className="text-3xl font-bold text-scryn-text mb-3">Reward Delivered!</h1>
            <p className="text-scryn-muted mb-8">
              Your reward has been successfully processed and will be delivered to your phone shortly.
            </p>

            <div className="bg-white rounded-2xl border border-scryn-border p-6 mb-8">
              <p className="text-sm text-scryn-muted mb-2">Reference ID</p>
              <div className="flex items-center justify-center gap-2">
                <code className="text-lg font-mono font-semibold text-scryn-text">{referenceId}</code>
                <button
                  onClick={() => navigator.clipboard.writeText(referenceId)}
                  className="p-2 rounded-lg hover:bg-scryn-bg transition-colors"
                  aria-label="Copy reference ID"
                >
                  <Copy className="w-4 h-4 text-scryn-muted" />
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/redeem" className="btn-secondary w-full sm:w-auto">
                <RotateCcw className="w-4 h-4 mr-2" />
                Redeem Another
              </Link>
              <Link href="/" className="btn-primary w-full sm:w-auto">
                <Home className="w-4 h-4 mr-2" />
                Return Home
              </Link>
            </div>

            <p className="text-xs text-scryn-muted mt-8">
              Need help? <a href="/contact" className="text-scryn-primary hover:underline">Contact support</a> with your reference ID.
            </p>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
