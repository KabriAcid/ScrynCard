'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Gift, Hash, KeyRound, ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function RedeemPage() {
  const [serialNumber, setSerialNumber] = useState('');
  const [giftCode, setGiftCode] = useState('');
  const [errors, setErrors] = useState<{ serial?: string; code?: string }>({});

  const validate = () => {
    const newErrors: { serial?: string; code?: string } = {};
    if (!serialNumber.trim()) newErrors.serial = 'Serial number is required';
    if (!giftCode.trim()) newErrors.code = 'Gift code is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (validate()) {
      window.location.href = '/redeem/verify';
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
              <Gift className="w-8 h-8 text-scryn-primary" />
            </div>
            <h1 className="text-2xl font-bold text-scryn-text mb-2">Redeem Your Card</h1>
            <p className="text-scryn-muted text-sm">Enter your card details to claim your reward.</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
          >
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-scryn-text mb-2">Serial Number</label>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                  <input
                    type="text"
                    placeholder="e.g., SCR-1234-5678"
                    className={`input pl-12 ${errors.serial ? 'border-red-400 focus:border-red-400 focus:ring-red-400/20' : ''}`}
                    value={serialNumber}
                    onChange={(e) => setSerialNumber(e.target.value)}
                  />
                </div>
                {errors.serial && <p className="mt-1.5 text-xs text-red-500">{errors.serial}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-scryn-text mb-2">Gift Code</label>
                <div className="relative">
                  <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-scryn-muted" />
                  <input
                    type="text"
                    placeholder="e.g., ABCD-1234-EFGH"
                    className={`input pl-12 ${errors.code ? 'border-red-400 focus:border-red-400 focus:ring-red-400/20' : ''}`}
                    value={giftCode}
                    onChange={(e) => setGiftCode(e.target.value)}
                  />
                </div>
                {errors.code && <p className="mt-1.5 text-xs text-red-500">{errors.code}</p>}
              </div>
            </div>

            <button
              onClick={handleContinue}
              className="btn-primary w-full mt-8 group"
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>

          <p className="text-center text-xs text-scryn-muted mt-6">
            Need help? <a href="/contact" className="text-scryn-primary hover:underline">Contact support</a>
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
