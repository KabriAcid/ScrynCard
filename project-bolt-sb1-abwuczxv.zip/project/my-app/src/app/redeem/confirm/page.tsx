'use client';

import { motion } from 'framer-motion';
import { CheckCircle, Smartphone, Wifi, Hash, ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function ConfirmPage() {
  const handleRedeem = () => {
    window.location.href = '/redeem/success';
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
              <CheckCircle className="w-8 h-8 text-scryn-primary" />
            </div>
            <h1 className="text-2xl font-bold text-scryn-text mb-2">Confirm Redemption</h1>
            <p className="text-scryn-muted text-sm">Review your details before confirming.</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-scryn-border">
                <div className="flex items-center gap-3">
                  <Wifi className="w-4 h-4 text-scryn-muted" />
                  <span className="text-sm text-scryn-muted">Reward</span>
                </div>
                <span className="text-sm font-semibold text-scryn-text">1GB Data</span>
              </div>

              <div className="flex items-center justify-between py-3 border-b border-scryn-border">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-4 h-4 text-scryn-muted" />
                  <span className="text-sm text-scryn-muted">Phone Number</span>
                </div>
                <span className="text-sm font-semibold text-scryn-text">0801 234 5678</span>
              </div>

              <div className="flex items-center justify-between py-3 border-b border-scryn-border">
                <div className="flex items-center gap-3">
                  <Hash className="w-4 h-4 text-scryn-muted" />
                  <span className="text-sm text-scryn-muted">Network</span>
                </div>
                <span className="text-sm font-semibold text-scryn-text">MTN</span>
              </div>

              <div className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <Hash className="w-4 h-4 text-scryn-muted" />
                  <span className="text-sm text-scryn-muted">Card Value</span>
                </div>
                <span className="text-sm font-semibold text-scryn-text">₦500</span>
              </div>
            </div>

            <button
              onClick={handleRedeem}
              className="btn-primary w-full mt-8 group"
            >
              Redeem Reward
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
