'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Smartphone, ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const networks = [
  { id: 'mtn', label: 'MTN', color: 'bg-yellow-400 text-yellow-900' },
  { id: 'airtel', label: 'Airtel', color: 'bg-red-500 text-white' },
  { id: 'glo', label: 'Glo', color: 'bg-green-500 text-white' },
  { id: '9mobile', label: '9mobile', color: 'bg-teal-500 text-white' },
];

export default function VerifyPage() {
  const [phone, setPhone] = useState('');
  const [network, setNetwork] = useState('');
  const [errors, setErrors] = useState<{ phone?: string; network?: string }>({});

  const validate = () => {
    const newErrors: { phone?: string; network?: string } = {};
    if (!phone.trim()) newErrors.phone = 'Phone number is required';
    if (!network) newErrors.network = 'Please select a network';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (validate()) {
      window.location.href = '/redeem/options';
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
              <Smartphone className="w-8 h-8 text-scryn-primary" />
            </div>
            <h1 className="text-2xl font-bold text-scryn-text mb-2">Verify Your Phone</h1>
            <p className="text-scryn-muted text-sm">Enter your phone number and select your network.</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl border border-scryn-border p-6 lg:p-8"
          >
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-scryn-text mb-2">Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g., 0801 234 5678"
                  className={`input ${errors.phone ? 'border-red-400 focus:border-red-400 focus:ring-red-400/20' : ''}`}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
                {errors.phone && <p className="mt-1.5 text-xs text-red-500">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-scryn-text mb-2">Network</label>
                <div className="grid grid-cols-2 gap-3">
                  {networks.map((n) => (
                    <button
                      key={n.id}
                      onClick={() => setNetwork(n.id)}
                      className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all ${
                        network === n.id
                          ? `${n.color} shadow-md`
                          : 'bg-scryn-bg text-scryn-muted hover:bg-scryn-primary/10'
                      }`}
                    >
                      {n.label}
                    </button>
                  ))}
                </div>
                {errors.network && <p className="mt-1.5 text-xs text-red-500">{errors.network}</p>}
              </div>
            </div>

            <button
              onClick={handleContinue}
              className="btn-primary w-full mt-8 group"
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
