'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Wifi, Phone, ArrowRight, Check } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

interface RewardOption {
  id: string;
  type: 'data' | 'airtime';
  label: string;
  value: string;
  icon: typeof Wifi;
}

const rewardOptions: RewardOption[] = [
  { id: 'data', type: 'data', label: '1GB Data', value: '1GB', icon: Wifi },
  { id: 'airtime', type: 'airtime', label: '₦400 Airtime', value: '₦400', icon: Phone },
];

export default function OptionsPage() {
  const [selected, setSelected] = useState<string | null>(null);
  const cardValue = '₦500';
  const network = 'MTN';

  const handleContinue = () => {
    if (selected) {
      window.location.href = '/redeem/confirm';
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
              <Wifi className="w-8 h-8 text-scryn-primary" />
            </div>
            <h1 className="text-2xl font-bold text-scryn-text mb-2">Choose Your Reward</h1>
            <p className="text-scryn-muted text-sm">
              Card Value: <span className="font-semibold text-scryn-text">{cardValue}</span> · Network:{' '}
              <span className="font-semibold text-scryn-text">{network}</span>
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            {rewardOptions.map((option) => {
              const isSelected = selected === option.id;
              const Icon = option.icon;

              return (
                <button
                  key={option.id}
                  onClick={() => setSelected(option.id)}
                  className={`w-full flex items-center gap-4 p-5 rounded-2xl border-2 transition-all text-left ${
                    isSelected
                      ? 'border-scryn-primary bg-scryn-primary/5'
                      : 'border-scryn-border bg-white hover:border-scryn-primary/30'
                  }`}
                >
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      isSelected ? 'bg-scryn-primary text-white' : 'bg-scryn-bg text-scryn-muted'
                    }`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>

                  <div className="flex-1">
                    <div className="font-semibold text-scryn-text">{option.label}</div>
                    <div className="text-sm text-scryn-muted">{option.type === 'data' ? 'Mobile Data' : 'Airtime Credit'}</div>
                  </div>

                  <div
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      isSelected ? 'border-scryn-primary bg-scryn-primary' : 'border-scryn-border'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                  </div>
                </button>
              );
            })}
          </motion.div>

          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            onClick={handleContinue}
            disabled={!selected}
            className="btn-primary w-full mt-8 group disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </motion.button>
        </div>
      </main>
      <Footer />
    </div>
  );
}
