'use client';

import { motion } from 'framer-motion';
import { AlertCircle, RotateCcw, HelpCircle } from 'lucide-react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const errorTypes = [
  {
    title: 'Invalid Code',
    description: 'The serial number or gift code you entered is incorrect. Please double-check and try again.',
  },
  {
    title: 'Expired Card',
    description: 'This card has expired and is no longer valid for redemption.',
  },
  {
    title: 'Already Redeemed',
    description: 'This card has already been redeemed. Each card can only be used once.',
  },
  {
    title: 'Network Issue',
    description: 'We are experiencing technical difficulties. Please try again in a few minutes.',
  },
];

export default function ErrorPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20 flex items-center justify-center">
        <div className="section-padding w-full max-w-md mx-auto py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-5">
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
            <h1 className="text-2xl font-bold text-scryn-text mb-2">Redemption Failed</h1>
            <p className="text-scryn-muted text-sm">We could not process your redemption. See possible reasons below.</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-3 mb-10"
          >
            {errorTypes.map((error, i) => (
              <div
                key={error.title}
                className="bg-white rounded-xl border border-scryn-border p-4"
              >
                <h3 className="text-sm font-semibold text-scryn-text mb-1">{error.title}</h3>
                <p className="text-xs text-scryn-muted">{error.description}</p>
              </div>
            ))}
          </motion.div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/redeem" className="btn-secondary w-full sm:w-auto">
              <RotateCcw className="w-4 h-4 mr-2" />
              Try Again
            </Link>
            <Link href="/contact" className="btn-primary w-full sm:w-auto">
              <HelpCircle className="w-4 h-4 mr-2" />
              Contact Support
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
