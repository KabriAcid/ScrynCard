import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <div className="section-padding py-12 lg:py-20 max-w-3xl mx-auto">
          <h1 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Privacy Policy</h1>
          <p className="text-scryn-muted mb-10">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

          <div className="prose prose-neutral max-w-none">
            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">1. Introduction</h2>
              <p className="text-scryn-muted leading-relaxed">
                Scryn (&quot;we,&quot; &quot;our,&quot; or &quot;us&quot;) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">2. Information We Collect</h2>
              <p className="text-scryn-muted leading-relaxed mb-3">We may collect the following types of information:</p>
              <ul className="list-disc list-inside text-scryn-muted space-y-1">
                <li>Personal identification information (name, email, phone number)</li>
                <li>Business information (company name, industry)</li>
                <li>Card redemption data (serial numbers, gift codes)</li>
                <li>Usage data and analytics</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">3. How We Use Your Information</h2>
              <p className="text-scryn-muted leading-relaxed mb-3">We use the information we collect to:</p>
              <ul className="list-disc list-inside text-scryn-muted space-y-1">
                <li>Process card orders and redemptions</li>
                <li>Communicate with you about your account</li>
                <li>Improve our platform and services</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">4. Data Security</h2>
              <p className="text-scryn-muted leading-relaxed">
                We implement appropriate technical and organizational measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">5. Contact Us</h2>
              <p className="text-scryn-muted leading-relaxed">
                If you have any questions about this Privacy Policy, please contact us at{' '}
                <a href="mailto:hello@scryn.com" className="text-scryn-primary hover:underline">hello@scryn.com</a>.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
