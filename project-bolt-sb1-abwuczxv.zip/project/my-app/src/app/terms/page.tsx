import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function TermsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <div className="section-padding py-12 lg:py-20 max-w-3xl mx-auto">
          <h1 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Terms of Service</h1>
          <p className="text-scryn-muted mb-10">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

          <div className="prose prose-neutral max-w-none">
            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">1. Acceptance of Terms</h2>
              <p className="text-scryn-muted leading-relaxed">
                By accessing or using the Scryn platform, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">2. Description of Service</h2>
              <p className="text-scryn-muted leading-relaxed">
                Scryn provides a digital reward card infrastructure platform that enables businesses to create, order, distribute, and track branded reward cards for their customers.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">3. Card Orders</h2>
              <p className="text-scryn-muted leading-relaxed">
                All card orders are subject to review and approval. Minimum order quantities apply. Delivery timelines are estimates and may vary based on order complexity and volume.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">4. Redemption</h2>
              <p className="text-scryn-muted leading-relaxed">
                Reward cards are valid for redemption within the specified period. Each card can only be redeemed once. Scryn reserves the right to void cards suspected of fraud or misuse.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">5. Limitation of Liability</h2>
              <p className="text-scryn-muted leading-relaxed">
                Scryn shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use the service.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-bold text-scryn-text mb-3">6. Contact</h2>
              <p className="text-scryn-muted leading-relaxed">
                For questions about these Terms, please contact us at{' '}
                <a href="mailto:hello@scryn.com" className="text-scryn-primary hover:underline">hello@scryn.com</a>.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
