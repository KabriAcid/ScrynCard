import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import TrustedBy from "@/components/TrustedBy";
import HowItWorks from "@/components/HowItWorks";
import UseCases from "@/components/UseCases";
import WhyScryn from "@/components/WhyScryn";
import CardShowcase from "@/components/CardShowcase";
import FAQ from "@/components/FAQ";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <Hero />
        <TrustedBy />
        <HowItWorks />
        <UseCases />
        <WhyScryn />
        <CardShowcase />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}
