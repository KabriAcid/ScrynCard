'use client';

import { motion } from 'framer-motion';
import { Target, Eye, Lightbulb, Rocket, Globe, Users } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const sections = [
  {
    icon: Target,
    title: 'Our Mission',
    content: 'To bridge the gap between offline customer engagement and digital rewards, creating measurable connections between businesses and their customers through premium physical reward cards.',
  },
  {
    icon: Eye,
    title: 'Our Vision',
    content: 'A world where every business can effortlessly reward customer loyalty, and every customer can seamlessly redeem meaningful rewards — no apps, no friction, just appreciation.',
  },
  {
    icon: Lightbulb,
    title: 'The Problem',
    content: 'Traditional rewards lack tracking, analytics, and security. Paper vouchers get lost, discounts go unmeasured, and businesses have no visibility into campaign effectiveness.',
  },
  {
    icon: Rocket,
    title: 'Our Solution',
    content: 'Scryn provides secure, branded reward cards with unique codes. Businesses distribute physical cards; customers redeem online for airtime or data. Every redemption is tracked and measured.',
  },
];

const industries = ['Hotels', 'Restaurants', 'Retail', 'Politics', 'Corporate', 'Events', 'Education', 'Religious'];

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 pt-16 lg:pt-20">
        <section className="py-20 lg:py-28 bg-gradient-to-b from-scryn-bg to-white">
          <div className="section-padding text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">About Us</p>
              <h1 className="text-4xl lg:text-5xl font-bold text-scryn-text mb-6">The Story of Scryn</h1>
              <p className="text-xl text-scryn-muted leading-relaxed">
                We are building the infrastructure for offline-to-digital rewards in Africa and beyond.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="section-padding max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {sections.map((section, i) => (
                <motion.div
                  key={section.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="card"
                >
                  <div className="w-12 h-12 rounded-xl bg-scryn-primary/10 flex items-center justify-center mb-5">
                    <section.icon className="w-6 h-6 text-scryn-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-scryn-text mb-3">{section.title}</h3>
                  <p className="text-scryn-muted leading-relaxed">{section.content}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-scryn-bg">
          <div className="section-padding max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-12 h-12 rounded-xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
                <Globe className="w-6 h-6 text-scryn-primary" />
              </div>
              <h2 className="text-3xl font-bold text-scryn-text mb-4">Industries We Serve</h2>
              <p className="text-scryn-muted">From hospitality to politics, Scryn powers rewards across sectors.</p>
            </motion.div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              {industries.map((ind, i) => (
                <motion.span
                  key={ind}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="px-5 py-2.5 rounded-full bg-white border border-scryn-border text-sm font-medium text-scryn-text"
                >
                  {ind}
                </motion.span>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="section-padding max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="w-12 h-12 rounded-xl bg-scryn-primary/10 flex items-center justify-center mx-auto mb-5">
                <Rocket className="w-6 h-6 text-scryn-primary" />
              </div>
              <h2 className="text-3xl font-bold text-scryn-text mb-4">Future Roadmap</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-10">
                {[
                  { phase: 'Q2 2024', title: 'Launch', desc: 'Nigeria-wide card distribution and redemption.' },
                  { phase: 'Q4 2024', title: 'Expand', desc: 'Pan-African rollout with multi-currency support.' },
                  { phase: '2025', title: 'Scale', desc: 'Business dashboard, API access, and white-label solutions.' },
                ].map((item, i) => (
                  <div key={item.phase} className="bg-white rounded-2xl border border-scryn-border p-6">
                    <div className="text-xs font-semibold text-scryn-primary uppercase tracking-wider mb-2">{item.phase}</div>
                    <h3 className="text-lg font-bold text-scryn-text mb-2">{item.title}</h3>
                    <p className="text-sm text-scryn-muted">{item.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
