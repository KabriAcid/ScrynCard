'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Fingerprint, Menu, X } from 'lucide-react';

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/gallery', label: 'Card Gallery' },
  { href: '/order', label: 'Order Cards' },
  { href: '/redeem', label: 'Redeem' },
  { href: '/about', label: 'About' },
  { href: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-scryn-border">
      <nav className="section-padding flex items-center justify-between h-16 lg:h-20">
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-scryn-primary flex items-center justify-center group-hover:scale-105 transition-transform">
            <Fingerprint className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <span className="text-xl font-bold tracking-tight text-scryn-text">Scryn</span>
        </Link>

        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-scryn-muted hover:text-scryn-primary transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <Link href="/redeem" className="btn-secondary text-sm py-2.5 px-5">
            Redeem Card
          </Link>
          <Link href="/order" className="btn-primary text-sm py-2.5 px-5">
            Order Cards
          </Link>
        </div>

        <button
          className="lg:hidden p-2 text-scryn-text"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-scryn-border">
          <div className="section-padding py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="py-3 px-4 text-sm font-medium text-scryn-muted hover:text-scryn-primary hover:bg-scryn-bg rounded-lg transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-scryn-border">
              <Link href="/redeem" className="btn-secondary text-sm py-3" onClick={() => setMobileOpen(false)}>
                Redeem Card
              </Link>
              <Link href="/order" className="btn-primary text-sm py-3" onClick={() => setMobileOpen(false)}>
                Order Cards
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
