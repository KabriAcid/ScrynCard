'use client';

import { motion } from 'framer-motion';
import { Shield, Fingerprint, BarChart3, Palette, Truck, Lock } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Secure Redemption',
    description: 'Every card uses encrypted codes with multi-layer validation to prevent fraud.',
  },
  {
    icon: Fingerprint,
    title: 'Unique Codes',
    description: 'Each card has a one-of-a-kind serial number and gift code combination.',
  },
  {
    icon: BarChart3,
    title: 'Analytics',
    description: 'Track redemption rates, campaign ROI, and customer engagement in real-time.',
  },
  {
    icon: Palette,
    title: 'Branded Designs',
    description: 'Fully customizable cards that reflect your brand identity and colors.',
  },
  {
    icon: Truck,
    title: 'Offline Distribution',
    description: 'Physical cards work anywhere — no app downloads or tech barriers for customers.',
  },
  {
    icon: Lock,
    title: 'Fraud Protection',
    description: 'Advanced detection systems prevent duplicate redemptions and unauthorized use.',
  },
];

export default function WhyScryn() {
  return (
    <section className="py-24 lg:py-32 bg-scryn-bg">
      <div className="section-padding">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Why Scryn</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Built for Security & Scale</h2>
          <p className="text-scryn-muted text-lg">Enterprise-grade infrastructure that grows with your business.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="card"
            >
              <div className="w-12 h-12 rounded-xl bg-scryn-primary/10 flex items-center justify-center mb-5">
                <feature.icon className="w-6 h-6 text-scryn-primary" />
              </div>
              <h3 className="text-lg font-semibold text-scryn-text mb-2">{feature.title}</h3>
              <p className="text-sm text-scryn-muted leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
