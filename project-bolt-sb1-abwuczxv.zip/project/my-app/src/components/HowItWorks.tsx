'use client';

import { motion } from 'framer-motion';
import { ShoppingCart, ShieldCheck, Truck, Smartphone, BarChart3 } from 'lucide-react';

const steps = [
  {
    icon: ShoppingCart,
    title: 'Business Orders Cards',
    description: 'Select your card design, denomination, and quantity through our simple order form.',
  },
  {
    icon: ShieldCheck,
    title: 'Scryn Generates Cards',
    description: 'We create secure, branded reward cards with unique serial numbers and gift codes.',
  },
  {
    icon: Truck,
    title: 'Cards Distributed',
    description: 'Physical cards are delivered to your business for customer distribution.',
  },
  {
    icon: Smartphone,
    title: 'Customers Redeem',
    description: 'Recipients enter their serial number and gift code to claim their reward.',
  },
  {
    icon: BarChart3,
    title: 'Track Performance',
    description: 'Monitor redemption rates, campaign success, and customer engagement metrics.',
  },
];

export default function HowItWorks() {
  return (
    <section className="py-24 lg:py-32 bg-scryn-bg">
      <div className="section-padding">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">How It Works</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Simple. Secure. Scalable.</h2>
          <p className="text-scryn-muted text-lg">From order to redemption in five easy steps.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-2xl bg-scryn-primary/10 flex items-center justify-center mb-5">
                  <step.icon className="w-7 h-7 text-scryn-primary" />
                </div>
                <div className="w-8 h-8 rounded-full bg-scryn-primary text-white flex items-center justify-center text-sm font-bold mb-4">
                  {i + 1}
                </div>
                <h3 className="text-lg font-semibold text-scryn-text mb-2">{step.title}</h3>
                <p className="text-sm text-scryn-muted leading-relaxed">{step.description}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-[60%] w-[80%] h-px bg-gradient-to-r from-scryn-primary/30 to-transparent" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
