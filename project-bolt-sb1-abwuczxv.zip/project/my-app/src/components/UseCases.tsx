'use client';

import { motion } from 'framer-motion';
import { Hotel, UtensilsCrossed, ShoppingBag, Vote, Building2, Megaphone, PartyPopper, GraduationCap, Church } from 'lucide-react';

const industries = [
  { icon: Hotel, name: 'Hotels', description: 'Reward loyal guests with complimentary stays and upgrades.' },
  { icon: UtensilsCrossed, name: 'Restaurants', description: 'Offer free meals, discounts, and special dining experiences.' },
  { icon: ShoppingBag, name: 'Retail', description: 'Drive repeat purchases with store credit and exclusive offers.' },
  { icon: Vote, name: 'Politics', description: 'Engage supporters with campaign merchandise and event access.' },
  { icon: Building2, name: 'Corporate', description: 'Recognize employees with gift cards and wellness perks.' },
  { icon: Megaphone, name: 'Influencers', description: 'Reward subscribers with exclusive content and merchandise.' },
  { icon: PartyPopper, name: 'Events', description: 'Provide attendees with VIP access and special privileges.' },
  { icon: GraduationCap, name: 'Education', description: 'Incentivize students with book vouchers and supplies.' },
  { icon: Church, name: 'Religious', description: 'Appreciate congregation members with community rewards.' },
];

export default function UseCases() {
  return (
    <section className="py-24 lg:py-32 bg-white">
      <div className="section-padding">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Industries</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Cards for Every Business</h2>
          <p className="text-scryn-muted text-lg">From hospitality to politics, Scryn serves diverse industries.</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {industries.map((industry, i) => (
            <motion.div
              key={industry.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="card group cursor-default"
            >
              <div className="w-12 h-12 rounded-xl bg-scryn-primary/10 flex items-center justify-center mb-4 group-hover:bg-scryn-primary group-hover:text-white transition-colors">
                <industry.icon className="w-6 h-6 text-scryn-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-scryn-text mb-2">{industry.name}</h3>
              <p className="text-sm text-scryn-muted leading-relaxed">{industry.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
