'use client';

import { motion } from 'framer-motion';

const companies = [
  'Hilton Hotels',
  'Sheraton',
  'Shoprite',
  'Dominos',
  'Cold Stone',
  'Genesis',
];

export default function TrustedBy() {
  return (
    <section className="py-16 bg-white border-b border-scryn-border">
      <div className="section-padding">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center text-sm font-medium text-scryn-muted uppercase tracking-wider mb-10"
        >
          Trusted by leading brands
        </motion.p>
        <div className="flex flex-wrap items-center justify-center gap-8 lg:gap-16">
          {companies.map((company, i) => (
            <motion.div
              key={company}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 0.4, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-lg lg:text-xl font-semibold text-scryn-text hover:opacity-100 transition-opacity cursor-default"
            >
              {company}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
