'use client';

import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Gift } from 'lucide-react';
import { useState } from 'react';

const cards = [
  { name: 'Hotel Rewards', value: '₦5,000', color: 'from-amber-500 to-orange-600', pattern: 'radial-gradient(circle at 20% 50%, rgba(255,255,255,0.15) 0%, transparent 50%)' },
  { name: 'Restaurant Perks', value: '₦2,500', color: 'from-rose-500 to-pink-600', pattern: 'radial-gradient(circle at 80% 50%, rgba(255,255,255,0.15) 0%, transparent 50%)' },
  { name: 'Retail Offers', value: '₦1,000', color: 'from-blue-500 to-indigo-600', pattern: 'radial-gradient(circle at 50% 20%, rgba(255,255,255,0.15) 0%, transparent 50%)' },
  { name: 'Corporate Gifts', value: '₦10,000', color: 'from-emerald-500 to-teal-600', pattern: 'radial-gradient(circle at 50% 80%, rgba(255,255,255,0.15) 0%, transparent 50%)' },
  { name: 'Event Access', value: '₦3,000', color: 'from-violet-500 to-purple-600', pattern: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.15) 0%, transparent 50%)' },
];

export default function CardShowcase() {
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((c) => (c + 1) % cards.length);
  const prev = () => setCurrent((c) => (c - 1 + cards.length) % cards.length);

  return (
    <section className="py-24 lg:py-32 bg-white overflow-hidden">
      <div className="section-padding">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">Card Showcase</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Premium Card Designs</h2>
          <p className="text-scryn-muted text-lg">Beautiful, branded cards that customers love to receive.</p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={prev}
              className="hidden lg:flex w-12 h-12 rounded-full bg-scryn-bg items-center justify-center text-scryn-muted hover:text-scryn-primary hover:bg-scryn-primary/10 transition-colors"
              aria-label="Previous card"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <div className="flex-1 flex items-center justify-center gap-6 overflow-hidden py-8">
              {cards.map((card, i) => {
                const offset = i - current;
                const isActive = offset === 0;
                const isVisible = Math.abs(offset) <= 1;

                if (!isVisible) return null;

                return (
                  <motion.div
                    key={card.name}
                    initial={false}
                    animate={{
                      scale: isActive ? 1 : 0.85,
                      opacity: isActive ? 1 : 0.5,
                      x: offset * 60,
                      zIndex: isActive ? 10 : 1,
                    }}
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    className={`relative w-72 lg:w-80 aspect-[1.586/1] rounded-2xl bg-gradient-to-br ${card.color} shadow-2xl flex flex-col justify-between p-6 cursor-default ${
                      isActive ? 'shadow-scryn-primary/20' : ''
                    }`}
                    style={{ backgroundImage: card.pattern }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                          <Gift className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-white/90 text-sm font-medium">Scryn</span>
                      </div>
                      <span className="text-white/60 text-xs font-mono">{card.value}</span>
                    </div>

                    <div>
                      <div className="text-white/60 text-xs mb-1">Gift Card</div>
                      <div className="text-white text-lg font-bold">{card.name}</div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-white/40 text-[10px] font-mono tracking-widest">XXXX-XXXX-XXXX</div>
                      <div className="w-10 h-8 rounded bg-white/20" />
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <button
              onClick={next}
              className="hidden lg:flex w-12 h-12 rounded-full bg-scryn-bg items-center justify-center text-scryn-muted hover:text-scryn-primary hover:bg-scryn-primary/10 transition-colors"
              aria-label="Next card"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 mt-8">
            {cards.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-all ${
                  i === current ? 'w-8 bg-scryn-primary' : 'bg-scryn-border hover:bg-scryn-muted'
                }`}
                aria-label={`Go to card ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
