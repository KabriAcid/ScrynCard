import Link from 'next/link';
import { Fingerprint, Mail, Phone, MapPin } from 'lucide-react';

const footerLinks = {
  Product: [
    { href: '/order', label: 'Order Cards' },
    { href: '/gallery', label: 'Card Gallery' },
    { href: '/redeem', label: 'Redeem Card' },
  ],
  Company: [
    { href: '/about', label: 'About Us' },
    { href: '/contact', label: 'Contact' },
  ],
  Legal: [
    { href: '/privacy', label: 'Privacy Policy' },
    { href: '/terms', label: 'Terms of Service' },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-white border-t border-scryn-border">
      <div className="section-padding py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2.5 mb-5">
              <div className="w-9 h-9 rounded-xl bg-scryn-primary flex items-center justify-center">
                <Fingerprint className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-xl font-bold tracking-tight text-scryn-text">Scryn</span>
            </Link>
            <p className="text-scryn-muted text-sm leading-relaxed max-w-sm mb-6">
              Transform customer appreciation into measurable engagement. Scryn provides premium digital reward card infrastructure for modern businesses.
            </p>
            <div className="flex flex-col gap-3 text-sm text-scryn-muted">
              <a href="mailto:hello@scryn.com" className="flex items-center gap-2 hover:text-scryn-primary transition-colors">
                <Mail className="w-4 h-4" />
                hello@scryn.com
              </a>
              <a href="tel:+2348001234567" className="flex items-center gap-2 hover:text-scryn-primary transition-colors">
                <Phone className="w-4 h-4" />
                +234 800 123 4567
              </a>
              <span className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Lagos, Nigeria
              </span>
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-sm font-semibold text-scryn-text mb-4">{category}</h4>
              <ul className="flex flex-col gap-3">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-scryn-muted hover:text-scryn-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t border-scryn-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-scryn-muted">
            &copy; {new Date().getFullYear()} Scryn. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-scryn-muted hover:text-scryn-primary transition-colors">
              <span className="sr-only">Twitter</span>
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.247 8.247 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg>
            </a>
            <a href="#" className="text-scryn-muted hover:text-scryn-primary transition-colors">
              <span className="sr-only">LinkedIn</span>
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" /></svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
