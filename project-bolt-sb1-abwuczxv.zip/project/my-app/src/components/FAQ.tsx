'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'How does Scryn work?',
    answer: 'Businesses order customized reward cards from Scryn. We generate secure cards with unique codes and deliver them. Customers receive physical cards and redeem rewards online by entering their serial number and gift code.',
  },
  {
    question: 'What rewards can customers redeem?',
    answer: 'Customers can redeem mobile airtime (MTN, Airtel, Glo, 9mobile) or mobile data bundles depending on their card value and selected network.',
  },
  {
    question: 'How long does card delivery take?',
    answer: 'Standard delivery takes 5-7 business days within Nigeria. Express delivery options are available for urgent orders.',
  },
  {
    question: 'Is there a minimum order quantity?',
    answer: 'Yes, the minimum order is 100 cards. This ensures cost-effectiveness and allows us to maintain our premium quality standards.',
  },
  {
    question: 'Can I customize the card design?',
    answer: 'Absolutely! You can upload your logo, brand colors, and custom messaging. Our design team will create a proof for your approval before production.',
  },
  {
    question: 'What happens if a card is lost?',
    answer: 'Each card has a unique serial number. If a card is lost before redemption, contact our support team with the serial number and we can assist with recovery or replacement depending on your policy.',
  },
  {
    question: 'How do I track redemption analytics?',
    answer: 'Business dashboard (coming soon) will provide real-time analytics on redemption rates, geographic distribution, and campaign performance.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-24 lg:py-32 bg-scryn-bg">
      <div className="section-padding max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-sm font-semibold text-scryn-primary uppercase tracking-wider mb-3">FAQ</p>
          <h2 className="text-3xl lg:text-4xl font-bold text-scryn-text mb-4">Common Questions</h2>
          <p className="text-scryn-muted text-lg">Everything you need to know about Scryn.</p>
        </motion.div>

        <div className="flex flex-col gap-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-white rounded-2xl border border-scryn-border overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className="font-semibold text-scryn-text pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-scryn-muted flex-shrink-0 transition-transform duration-300 ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 text-scryn-muted leading-relaxed">{faq.answer}</div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
